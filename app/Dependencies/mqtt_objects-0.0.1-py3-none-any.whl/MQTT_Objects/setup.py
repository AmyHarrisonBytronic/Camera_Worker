from pathlib import Path
from setuptools import setup, find_packages

ROOT_DIR = Path(__file__).resolve().parents[2]
REQUIREMENTS_PATH = ROOT_DIR / 'requirements.txt'
README_PATH = ROOT_DIR / 'README.md'

with REQUIREMENTS_PATH.open('r', encoding='utf-16') as f:
    requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]

setup(
    name='MQTT_Objects',
    version='0.0.1',
    include_package_data=True,
    python_requires='>=3.9',
    packages=find_packages(where=str(ROOT_DIR / 'src')),
    package_dir={'': 'src'},
    install_requires=requirements,
    author='Amy Harrison',
    author_email='amy.harrison@bytronic.com',
    description='A package for MQTT objects related to camera and image processing',
    long_description=README_PATH.read_text(encoding='utf-8'),
    long_description_content_type='text/markdown',
    classifiers=[
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)
