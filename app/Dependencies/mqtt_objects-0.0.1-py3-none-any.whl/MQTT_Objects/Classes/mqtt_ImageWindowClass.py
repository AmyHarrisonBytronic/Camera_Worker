import cv2
import numpy as np
from .mqttClass import mqttClass
import time
import asyncio
import paho.mqtt.client as mqtt

class ImageWindowClass(mqttClass):
    def __init__(self):
        super().__init__()
        self.client = None
        self.window = None

    def DisplayImage(self, image: np.ndarray) -> None:
        #display the image in a window
        #function will return nothing
        cv2.imshow('Camera Image', image)
        cv2.waitKey(1)
        #cv2.destroyAllWindows()

    async def ListenForMessage(self,listen_and_diaplay:bool = True, stop_after_one: bool = False) -> None:
        if self.client is None:
            raise RuntimeError("MQTT client is not connected")

        loop = asyncio.get_running_loop()
        future = loop.create_future()
        received = asyncio.Event()

        def on_message(client, userdata, msg: mqtt.MQTTMessage):
            print("message received")
            try:
                nparr = np.frombuffer(msg.payload, np.uint8)
                image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                if image is None:
                    raise ValueError("decode failed")
            except Exception as e:
                print("decode error:", e)
                return
            
            # hand off to asyncio loop / UI thread
            if listen_and_diaplay:
                loop.call_soon_threadsafe(self.DisplayImage, image)
            loop.call_soon_threadsafe(future.set_result, image)

            print("image received at", time.time())
            if stop_after_one:
                loop.call_soon_threadsafe(received.set)

        self.client.on_message = on_message
        self.client.loop_start()

        try:
            if stop_after_one:
                await received.wait()
                return await future
            else:
                # keep alive until cancelled
                while True:
                    await asyncio.sleep(3600)
        finally:
            self.client.loop_stop()