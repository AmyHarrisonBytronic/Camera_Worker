import cv2
import numpy as np
from .mqttClass import mqttClass

class CameraClass(mqttClass):
    def __init__(self):
        #initialize the camera
        super().__init__()

        self.client = None
        self.cam = None

    def ConnectToCamera(self) -> None:
        #connect to the camera
        #function will return nothing
        try:
            self.cam = cv2.VideoCapture(0)
        except Exception as e:
            raise Exception("Error connecting to camera: " + str(e))
        
        if not self.cam.isOpened():
            raise Exception("Could not open camera.")

    def GetImageFromCamera(self) -> np.ndarray:
        #get the image from the camera and return it
        #function will return the image
        try:
            ret, image = self.cam.read()
        except Exception as e:
            raise Exception("Error reading image from camera: " + str(e))

        if not ret:
            raise Exception("Could not read image from camera.")
        return image

    def GetImage(self, image_path='.\\Images\\image.png') -> np.ndarray:
        #get the image from the camera and return it
        #function will return the image
        try:
            image = cv2.imread(image_path)
        except Exception as e:
            raise Exception("Error reading image from file: " + str(e))
        
        if image is None:
            raise Exception("Could not read image from file.")
        
        return image
    
    def PublishMessage(self, topic, image) -> None:
        if image is None:
            raise ValueError("Image cannot be None.")
        if topic is None:
            raise ValueError("Topic cannot be None.")

        # encode as JPEG (or PNG) first
        ok, buf = cv2.imencode('.jpg', image, [int(cv2.IMWRITE_JPEG_QUALITY), 90])
        if not ok:
            raise RuntimeError("Failed to encode image")
        payload = buf.tobytes()

        # publish and check result
        super().PublishMessage(topic, payload)
    
    def PixelBinning(self, image:np.ndarray, binning_x:int, binning_y:int) -> np.ndarray:
        #perform pixel binning on the image and return the binned image as a numpy array - very slow for large images and high binning factors, but it works
        #function will return the binned image as a numpy array
        if image is None:
            raise TypeError("image is None")
        if not isinstance(image, np.ndarray):
            raise TypeError("image must be a numpy array")
        if binning_x <= 0 or binning_y <= 0:
            raise ValueError("binning_x and binning_y must be positive integers")

        new_image = np.zeros((image.shape[0] // binning_y, image.shape[1] // binning_x, image.shape[2]), dtype=image.dtype)

        for y in range(0, image.shape[0], binning_y):
            for x in range(0, image.shape[1], binning_x):
                block = image[y:y+binning_y, x:x+binning_x]
                new_image[y//binning_y, x//binning_x] = block.mean(axis=(0, 1))
        
        return new_image