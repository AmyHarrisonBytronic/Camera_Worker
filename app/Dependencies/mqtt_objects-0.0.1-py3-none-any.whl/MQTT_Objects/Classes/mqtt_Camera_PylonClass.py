from pypylon import pylon
from .mqtt_CameraClass import CameraClass
import numpy as np
import time

class PylonClass(CameraClass):

    def __init__(self):
        super().__init__()
        self.VideoTopic = None

    def SetVideoTopic(self, topic) -> None:
        #set the topic for the video stream
        #function will return nothing
        if topic is None:
            raise Exception("Topic cannot be None.")
        
        self.VideoTopic = topic

    def _find_camera(self, timeout_ms: int = 5000) -> pylon.InstantCamera:
        #find the first available camera and return it - this is very messy clean this up please
        #function will return the camera object
        timeout_s = timeout_ms / 1000.0
        start = time.time()
        cam = None

        try:
            device = pylon.TlFactory.GetInstance().CreateFirstDevice()
            cam = pylon.InstantCamera(device)
            print("Camera found: %s", cam.GetDeviceInfo().GetModelName())
            return cam
        except Exception as e:
            raise Exception("Error finding camera: " + str(e))

    def ConnectToCamera(self, timeout_ms: int = 5000) -> pylon.InstantCamera:
        #connect to the camera and return the camera object - this is very messy clean this up please
        #function will return the camera object
        timeout_s = timeout_ms / 1000.0
        start = time.time()
        cam = None

        cam = self._find_camera(timeout_ms)

        try:
            if not cam.IsOpen():
                try:
                    cam.Open()
                except Exception as e:
                    # Open may fail transiently; continue to wait until timeout
                    print("Initial Open() failed; entering wait loop", exc_info=True)

            while not cam.IsOpen():
                if time.time() - start > timeout_s:
                    raise TimeoutError("Timeout while waiting for camera to open.")
                time.sleep(0.1)

            print("Camera connected successfully")
            return cam

        except Exception as e:
            print("Failed to connect to camera", exc_info=True)
            # ensure camera is closed on failure
            if cam is not None and cam.IsOpen():
                try:
                    cam.Close()
                    raise RuntimeError("Failed to open camera within timeout, but camera was opened. Closed camera to clean up.")
                except Exception:
                    raise RuntimeError("Failed to close camera after error", exc_info=True)

    def GetImageFromCamera(self, camera: pylon.InstantCamera, timeout_ms: int = 5000, isConverted=True) -> np.ndarray:
        #capture an image from the camera and return it as a numpy array
        #function will return the image as a numpy array
        if camera is None:
            raise ValueError("camera is None")
        if not camera.IsOpen():
            raise RuntimeError("camera is not open")

        timeout_s = timeout_ms / 1000.0

        try:
            grab_result = camera.GrabOne(timeout_ms)  # pylon expects ms
        except Exception as e:
            print("GrabOne raised an exception")
            raise RuntimeError("Failed to grab image") from e

        try:
            if not grab_result.GrabSucceeded():
                error_code = getattr(grab_result, "ErrorCode", None)
                error_desc = getattr(grab_result, "ErrorDescription", None)
                raise RuntimeError("Image grab failed: %s %s", error_code, error_desc)

            img = grab_result.Array  # type: ignore

            # Optionally convert pixel format here if needed, e.g., to BGR for OpenCV
            if isConverted:
                converter = pylon.ImageFormatConverter()
                converter.OutputPixelFormat = pylon.PixelType_BGR8packed
                converted = converter.Convert(grab_result)
                img = converted.Array

            print("Captured image shape: %s", getattr(img, "shape", None))
            return np.asarray(img)

        finally:
            # release GrabResult if required by wrapper
            try:
                grab_result.Release()
            except Exception:
                print("Failed to release grab_result", exc_info=True)
 
    def disconnectCamera(self, camera) -> None:
        #disconnect the camera
        #function will return nothing
        if camera is not None and camera.IsOpen():
            camera.Close()


    #i dont think this one works?
    async def ContinuousImageCapture(self, camera, timeout=5000) -> None:
        #continuously capture images from the camera and publish them to MQTT broker
        #function will return nothing
        camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly) 
        converter = pylon.ImageFormatConverter()
        converter.OutputPixelFormat = pylon.PixelType_BGR8packed
        converter.OutputBitAlignment = pylon.OutputBitAlignment_MsbAligned

        while camera.IsGrabbing():
            grabResult = camera.RetrieveResult(timeout, pylon.TimeoutHandling_ThrowException)

            if grabResult.GrabSucceeded():
                image = converter.Convert(grabResult)
                image_array = image.GetArray()
                self.PublishMessage(self.VideoTopic, image_array)
            else:
                print("Error: ", grabResult.ErrorCode, grabResult.ErrorDescription)

    