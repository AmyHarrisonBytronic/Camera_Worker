import paho.mqtt.client as mqtt
import asyncio

class mqttClass:
    def __init__(self):
        self.client = None
        self.timeout = 10  # seconds, for waiting for ACKs or other responses
        #ideally this would be more elegent and also connect/subscribe but i am lazy
    
    def _check_valid_ip(self, ip: str) -> None:
        #check if the IP address is valid
        #function will return nothing, but will raise an error if the IP address is invalid
        if ip == "localhost":
            return

        
        
        parts = ip.split(".")

        if len(parts) != 4:
            raise ValueError("IP must be in the format x.x.x.x")
        for part in parts:
            if not part.isdigit():
                raise ValueError("IP must be in the format x.x.x.x")
            num = int(part)
            if num < 0 or num > 255:
                raise ValueError("Octets in IP must be between 0 and 255")
    
    def _check_valid_mac(self, mac: str) -> None:
        #check if the MAC address is valid
        #function will return nothing, but will raise an error if the MAC address is invalid
        if mac is None:
            return
        
        if mac is not None and not isinstance(mac, str):
            raise ValueError("MAC must be a string in the format xx:xx:xx:xx:xx:xx")
        
        parts = mac.split(":")

        if len(parts) != 6:
            raise ValueError("MAC must be in the format xx:xx:xx:xx:xx:xx")
        for part in parts:
            if len(part) != 2 or not all(c in "0123456789abcdefABCDEF" for c in part):
                raise ValueError("MAC must be in the format xx:xx:xx:xx:xx:xx")
    
    def _check_valid_port(self, port: int) -> None:
        #check if the port number is valid
        #function will return nothing, but will raise an error if the port number is invalid
        if not isinstance(port, int):
            raise ValueError("Port must be an integer")
        if port <= 0 or port > 65535:
            raise ValueError("Port must be between 1 and 65535")

    def ConnectToServer(self, IP: str, PORT: int) -> None:
        #connect to the MQTT broker
        #function will return nothing
        if self.client is not None:
            raise RuntimeError("MQTT client is already connected")
        if not isinstance(IP, str) or not isinstance(PORT, int):
            raise ValueError("IP must be a string and PORT must be an integer")
        
        self._check_valid_port(PORT)
        self._check_valid_ip(IP)

        self.client = mqtt.Client()
        try:    
            self.client.connect(IP, PORT, 60)
        except Exception as e:
            raise ConnectionRefusedError(f"Failed to connect to MQTT broker: {e}")

    def SubscribeToTopic(self, topic: str) -> None:
        #subscribe to the MQTT topic
        #function will return nothing
        if not isinstance(topic, str):
            raise ValueError("Topic must be a string")
        if self.client is None:
            raise RuntimeError("MQTT client is not connected")
        print("subscribing to " + topic )

        rc, mid = self.client.subscribe(topic)
        print("subscribe rc:", rc, "mid:", mid)
        if rc != 0:
            raise RuntimeError(f"subscribe failed (rc={rc})")


    def DisconnectFromServer(self) -> None:
        #disconnect from the MQTT broker
        #function will return nothing
        if self.client is not None:
            self.client.loop_stop()
            self.client.disconnect()
            self.client = None
            

    def PublishMessage(self, topic: str, message: bytes, wait_for_ack=False) -> None:
        #publish a message to the MQTT broker
        #function will return nothing
        if self.client is None:
            raise RuntimeError("MQTT client is not connected")
        if not isinstance(topic, str):
            raise ValueError("Topic must be a string")
        if not isinstance(message, bytes):
            raise ValueError("Message must be bytes")
        
        self.client.publish(topic, message)
        if wait_for_ack:
            self.WaitForAck(topic)

    async def ListenForMessage(self, stop_after_one: bool = False) -> bytes | None:
        if self.client is None:
            raise RuntimeError("MQTT client is not connected")

        loop = asyncio.get_running_loop()
        future = loop.create_future()

        def on_message(client, userdata, msg: mqtt.MQTTMessage):
            print("message received:", msg.topic, "len=", len(msg.payload))
            try:
                payload = msg.payload.decode("utf-8")
            except Exception:
                payload = msg.payload

            print("Decoded message:", payload)
            if not future.done():
                loop.call_soon_threadsafe(future.set_result, payload)

        self.client.on_message = on_message
        self.client.loop_start()

        try:
            result = await future
            return result
        finally:
            self.client.loop_stop()

    def AckMessage(self, topic: str) -> None:
        #acknowledge the message received from the MQTT broker
        #function will return nothing
        if self.client is None:
            raise RuntimeError("MQTT client is not connected")
        if not isinstance(topic, str):
            raise ValueError("Topic must be a string")
        self.client.publish(topic, "ACK")

    def WaitForAck(self, topic: str) -> None:
        #wait for the acknowledgment message from the MQTT broker
        #function will return nothing
        #note: this is a blocking function and should be used with caution, find a way to run this async and also add a timeout
        if self.client is None:
            raise RuntimeError("MQTT client is not connected")
        if not isinstance(topic, str):
            raise ValueError("Topic must be a string")

        def on_message(client, userdata, msg):
            if msg.topic == topic and msg.payload.decode() == "ACK":
                # Acknowledgment received
                pass

        self.client.on_message = on_message
        try:
            self.client.loop_forever(self.timeout)
        except Exception as e:
            raise TimeoutError(f"Timeout waiting for ACK on topic '{topic}': {e}")