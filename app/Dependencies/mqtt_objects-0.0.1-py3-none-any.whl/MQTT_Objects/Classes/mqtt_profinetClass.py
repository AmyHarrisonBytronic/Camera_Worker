import profinet
from .mqttClass import mqttClass


class mqtt_profinetClass(mqttClass):
    def __init__(self):
        super().__init__()
        
    def FindProfinetDevices(self) -> list[str]:
        #find profinet devices on the network and return a list of their IP addresses - note this is not tested
        #function will return a list of IP addresses
        devices = profinet.scan()
        if not devices:
            raise Exception("No Profinet devices found on the network.")
        return [device.ip for device in devices]
    
    def GetProfinetDevice(self, ip_address, mac_address) -> profinet.device:
        #get the profinet device with the specified IP address and return it - note this is not tested
        #function will return the profinet device object
        self._check_valid_ip(ip_address)
        self._check_valid_mac(mac_address)

        devices = profinet.scan()
        for device in devices:
            if device.ip != ip_address:
                continue
            if mac_address is not None and device.mac != mac_address:
                continue  # Skip if MAC address does not match
            return device
        
        raise Exception("Profinet device with IP address " + ip_address + " not found.")