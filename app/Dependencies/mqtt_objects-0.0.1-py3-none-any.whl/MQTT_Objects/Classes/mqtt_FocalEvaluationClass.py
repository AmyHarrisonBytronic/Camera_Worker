import cv2
import numpy as np
from .mqttClass import mqttClass
import asyncio


class FocalEvaluationClass(mqttClass):
    def __init__(self):
        super().__init__()
        #global client
        self.client = None


    async def ListenForMessage(self, stop_after_one: bool = False) -> None:
        if self.client is None:
            raise RuntimeError("MQTT client is not connected")
        loop = asyncio.get_running_loop()
        received = asyncio.Event()

        def on_message(client, userdata, msg):
            print("on_message:", msg.topic, "len=", len(msg.payload))
            # decode image
            try:
                import numpy as np
                nparr = np.frombuffer(msg.payload, np.uint8)
                image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                if image is None:
                    print("decode failed")
                    return
            except Exception as e:
                print("decode error:", e)
                return
            # hand off to loop thread (or queue to main/UI thread)
            loop.call_soon_threadsafe(self.HandleIncomingImage, image)
            if stop_after_one:
                loop.call_soon_threadsafe(received.set)

        self.client.on_message = on_message
        self.client.loop_start()
        try:
            if stop_after_one:
                await received.wait()
            else:
                while True:
                    await asyncio.sleep(3600)
        finally:
            self.client.loop_stop()

    def HandleIncomingImage(self, image):
        try:
            score = self.EvaluateImageFocus(image)
            print("Received image focus score:", score)
        except Exception as e:
            print("HandleIncomingImage error:", e)


    def EvaluateImageFocus(self, image) -> float:
        #evaluate the focus of the image using the variance of the Laplacian
        #function will return a focus score (higher is better)
        if image is None:
            raise ValueError("Image cannot be None.")
        if not isinstance(image, np.ndarray):
            raise ValueError("Image must be a numpy array.")
        
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        return laplacian_var